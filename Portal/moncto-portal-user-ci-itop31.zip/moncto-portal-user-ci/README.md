# moncto-portal-user-ci

Extension iTop 3.1 pour ajouter dans le portail utilisateur :

- le champ **CI impactés** (`functionalcis_list`) dans le formulaire de création de ticket ;
- une tuile **Mes équipements** affichant les CI liés au contact connecté ;
- des scopes portail pour limiter la visibilité aux CI liés via `lnkPersonToCI`.

## Installation

1. Copier le dossier `moncto-portal-user-ci` dans le répertoire `extensions/` de l'instance iTop.
2. Relancer le setup iTop depuis l'interface web ou en CLI selon votre procédure habituelle.
3. Cocher / installer l'extension **Portal - CI de l'utilisateur sur les tickets**.
4. Vider le cache applicatif si nécessaire.

## Hypothèse de modèle

Le filtrage livré utilise la relation standard :

```sql
SELECT FunctionalCI AS f
JOIN lnkPersonToCI AS l ON l.ci_id = f.id
WHERE l.person_id = :current_contact_id
```

Si vos CI sont affectés aux utilisateurs autrement, adaptez les deux blocs OQL dans `datamodel.moncto-portal-user-ci.xml` :

- scope `FunctionalCI / user-linked-cis`
- brick `my-cis`

Exemple de filtre par organisation :

```sql
SELECT FunctionalCI WHERE org_id = :current_contact->org_id
```

## Point d'attention

Le formulaire `ticket-create` est redéfini avec `_delta="force"` pour insérer `functionalcis_list` à un emplacement maîtrisé. Si votre portail a déjà une personnalisation de ce formulaire, fusionnez manuellement le champ :

```xml
<div class="form_field" data-field-id="functionalcis_list" data-field-opened="true"/>
```

## Test rapide

- Connectez-vous avec un utilisateur portail dont le Contact est lié à au moins un CI via `lnkPersonToCI`.
- Ouvrez **Mes équipements** : seuls ses CI doivent apparaître.
- Créez une demande : le bloc **CI impactés** doit permettre d'ajouter un ou plusieurs CI.
