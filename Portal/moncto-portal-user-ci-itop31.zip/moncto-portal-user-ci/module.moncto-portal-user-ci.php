<?php
//
// iTop module definition file
//

SetupWebPage::AddModule(
    __FILE__,
    'moncto-portal-user-ci/1.0.0',
    array(
        'label' => 'Portal - CI de l\'utilisateur sur les tickets',
        'category' => 'business',
        'dependencies' => array(
            'itop-portal/3.1.0',
            'itop-portal-base/3.1.0',
            'itop-tickets/3.1.0',
            'itop-config-mgmt/3.1.0',
        ),
        'mandatory' => false,
        'visible' => true,
        'datamodel' => array(
            'model.moncto-portal-user-ci.php',
            'datamodel.moncto-portal-user-ci.xml',
        ),
        'webservice' => array(),
        'data.struct' => array(),
        'data.sample' => array(),
        'doc.manual_setup' => '',
        'doc.more_information' => '',
        'settings' => array(),
    )
);
